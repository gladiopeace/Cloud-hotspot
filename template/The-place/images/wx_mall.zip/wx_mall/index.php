<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title id="con_title">{{title}}</title>
    <script src="//portalcdn.cloudshotspot.com/template/wx_onekey/js/jquery.min.js"></script>
    <script src="//portalcdn.cloudshotspot.com/template/hotspot/js/bootstrap.min.js"></script>

    <link href="//portalcdn.cloudshotspot.com/template/hotspot/style/bootstrap.min.css" rel="stylesheet">
    <link href="//portalcdn.cloudshotspot.com/template/wx_mall/Content/style.css" rel="stylesheet" />
    <style type="text/css">
    .weixin{width: 92.5%;padding: 0px 30px 0px 30px;    
      /* background-image: url(//portalcdn.cloudshotspot.com/template/wx_mall//images/wechat.jpg); */
    text-align: center;
    
    background-image: none!important;
    background-position: center center;
    background-repeat: repeat;
    margin-top: 0px;
    position: absolute;
    z-index: 3;}

    .content {
      background-image:none!important; 
      text-align: center;

    }
    #init_content{width: 100%;height: 100%;z-index: 200;position: fixed;top: 0px;}
    .swiper-container {width: 100%;height: 39%;margin: 0px auto;}
    .tips{
      width: 100%;
      margin: 0px auto;
      position: fixed;
      bottom: -20px;
      text-align: center;
      height: 50px;
      z-index: 100;
      position: fixed;top: 88px;right: -60px;

    }

    #timeplace{width: 40px;height: 40px;border:1px solid white;border-radius:20px;display: block;    position: absolute;
    top: 0px;
    right: 98px;
        line-height: 40px;
    text-align: center;
  }

 
    .swiper{
      width: 100%;
      height: 100%;
      margin: 0px auto;
    }
    .swiper-slide {
        text-align: center;
        font-size: 18px;
        background: #fff;

        /* Center slide text vertically */
        display: -webkit-box;
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
        -webkit-box-align: center;
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
    }
    .swiper-slide img{width: 100%;/* height: auto; max-height: 300px; */ }
    
    </style>
    
</head>
<body>
    <div class="container-fluid  bg">
 
        <div class="container">
            <div class="row">

              
                <div class="col-xs-12 col-sm-12 col-md-5">
                    <div class="login">

                        <input id="mikrotik" data-status='false' type="hidden">

                        <div class="weixin hidden-md open">
                                              
                          <img src="//portalcdn.cloudshotspot.com/template/wx_mall//images/wechat_logo.jpg" style="height:100px;width:100px;border-radius:60px; -webkit-border-radius:60px;" onclick="onekey();"><br/>          
                          <a class="btn btn-success text-center" href="javascript:onekey();" role="button">一键连接Wi-Fi</a>

                       
                                                       
                          <br/>                            

                        </div>
                        <div class="content">
                          <br/><br/><br/><br/>   
                         
                        </div>

                        
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-7 advert">
                    <!-- 多图滚动 -->
                
                    <div id="scrollBox" class="scrollBox">
                        <div class="hd" >
                            <div style="float:left">
                                <span class="prev"></span>
                                <span class="next dir01"></span>
                            </div>
                            <ul></ul>

                        </div>
                        <div class="bd" id="banner">
                            <ul v-for="item in items">
                                <li>

                                    <a class="pic" href="{{item.url}}"><img :src="item.thumb"/></a>                                  
                                </li>                               
                            </ul>
                         
                        </div>
                    </div>
                   
                   
                </div>
            </div>
        </div>

    </div>

    <!-- screen -->

    <div id="init">
     
    <div id="init_content" v-show="ok">
      <div class="swiper">
           <div class="swiper-wrapper">
 
           
 
                 <div class="swiper-slide" v-for="item in items">
                   <img :src="item.thumb" style="height:100%;width:100%;">
                 </div>
 
 
           </div>
 
           <div class="tips" style="color:white;font-size:24px;font-fimaly:宋体,雅黑;">
         
            <div id='timeplace'>
             
              <span id="skip_time">{{ skip_time }}</span>s
           
              <a v-show='skip' href="javascript:void(0);" style="color:white;font-size:10px;font-fimaly:宋体,雅黑;text-decoration:none;position:relative;top:-10px;" onclick="remove_skip();">跳过</a>

            </div> 

    
       
 
 
           </div>
 
 
      </div>

    </div>
  
 
 
  </div>


    <script src="//portalcdn.cloudshotspot.com/template/wx_mall/Scripts/TouchSlide.1.1.js"></script>
    <script src="//portalcdn.cloudshotspot.com/cloud/js/vue/vue.min.js"></script>

     <script src="//portalcdn.cloudshotspot.com/template/hotspot/js/swiper.min.js"></script>
    <link rel="stylesheet" href="//portalcdn.cloudshotspot.com/template/hotspot/style/swiper.min.css">               
                    <!-- scrollBox E -->
    <script type="text/javascript">


        var $_GET = (function(){
        var url = window.document.location.href.toString();
        var u = url.split("?");
        if(typeof(u[1]) == "string"){
          u = u[1].split("&");
          var get = {};
          for(var i in u){
            var j = u[i].split("=");
            get[j[0]] = j[1];
          }
          return get;
        } else {
          return {};
        }

      })();


        var commonInit = [];
        var config = [];
        var skip_control;
    
        $(document).ready(function() {           
         
            $.ajax({
                url: '/portal/api/config',
                type: 'post',
                dataType: 'json',
                data: {'accesskey': $_GET['accesskey']},
              })
            .done(function(ret) {
                  //banner Json           
                  commonInit['banner'] = ret.banner;
                  //company Json
                  config['company'] = ret.copyright.company;
                  config['skip_time'] = ret.copyright.number;
                  config['title'] = ret.copyright.title;
                  
                  //alert(config['skip_time']);
                  //check if allow ads func
                  if(ret.copyright.screen=='accept'){
                    //ok 
                    config['screen'] = true;                    
                    //ads screen pic
                    commonInit['screen']= ret.screen; 
                    //check if allow skip ads
                    if(ret.copyright.type=='accept'){
                      //ok
                      config['skip'] = true; 
                      //config['skip'] = false; 
                    }else{
                      config['skip'] = false;
                    }
                  }else{
                    
                    commonInit['screen']= [];
                    config['screen'] =false;
                  }
                  do_api();
               
                  
            });
          
        });
       

        function do_api(){


          var vm = new Vue({
            el: '#banner',
            data: {             
              items:commonInit['banner'],               
            }
          });

          var vm_init = new Vue({
            el: '#init',
            data: { 
              ok:config['screen'],            
              skip:config['skip'],            
              skip_time:config['skip_time'],            
              items:commonInit['screen'],
            }
          });

           TouchSlide({
              slideCell:"#scrollBox",
              titCell:".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
              effect:"leftLoop",
              autoPage:true, //自动分页
              switchLoad:"_src" //切换加载，真实图片路径为"_src"
            });


           if(config['screen']){
             //广告
              var swiper = new Swiper('.swiper',{
                  pagination: false,
                  paginationClickable: true,
                  autoplay: 3000,
                  //autoplay: 2000,
              });
          }


          var vm = new Vue({
            el: '#company',
            data: {             
              company:config['company'],               
            }           
          });

          var vm = new Vue({
            el: '#con_title',
            data: {             
              title:config['title'],               
            }
          });

          if(config['screen']){
            skip_control=setInterval('skip_time()',1000); 

          }
        }

        function skip_time(){
         // alert(config['skip_time']);
          var time = parseInt(config['skip_time']);
          if(time==0){
            //clearIntervel(skip_control);
            clearInterval(skip_control);
            remove_skip();
            return;
          }
          //alert(time);
          //document.getElementById('skip_time').innerHtml='2';
          $("#skip_time").text(time);
          config['skip_time']--;

        }
      function remove_skip(){

        clearInterval(skip_control);
        $("#init").hide('fast/400');
      } 



      function onekey(){
        var url = "/portal/verify?accesskey="+$_GET['accesskey']+'&mac='+$_GET['mac']+'&ip='+$_GET['ip']+'&chaplogin='+$_GET['chaplogin'];
        window.location.href=url;
      }


      $(" .scrollBox .next").click(function () {
          if( $(this).hasClass("dir01")){
          
          }else{
              $(this).addClass("dir01")
              $(this).siblings("span").removeClass("dir")
          }
             
      })

      $(" .scrollBox .prev").click(function () {
          if ($(this).hasClass("dir")) {

          } else {
            $(this).addClass("dir")
            $(this).siblings("span").removeClass("dir01")
          }

      })


    </script>
</body>
</html>
