<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title id="con_title">{{title}}</title>      
    <link href="//portalcdn.cloudshotspot.com/template/wx_mall/Content/style.css" rel="stylesheet" />
    <script src="//portalcdn.cloudshotspot.com/template/wx_onekey/js/jquery.min.js"></script>
    <script src="//portalcdn.cloudshotspot.com/template/hotspot/js/bootstrap.min.js"></script>
    <link href="//portalcdn.cloudshotspot.com/template/hotspot/style/bootstrap.min.css" rel="stylesheet">
    <style>

       #qrcode_zone img{width: 100%;}

    </style>

</head>
<body>
    <div class="container-fluid  bg">
 
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-5">
                    <div class="login">

                        <input id="mikrotik" data-status='false' type="hidden">
                    
                        <!-- <div class="col-xs-6 col-md-6 on hidden-sm hidden-xs" ><a href="javascript:void(0)" id="weixin" >微信登录</a> -->
                        <div class="col-xs-6 col-md-6 on hidden-sm hidden-xs" ><a href="javascript:void(0)" >微信登录</a>
                        </div>
                        <div class="col-xs-6 col-md-6 on hidden-md hidden-lg">
                            <a href="javascript:void(0)" id="weixin01" onclick="onekey();">微信登录</a>
                        </div>
                        <div class="col-xs-6 col-md-6 on01" style="float:right">登录</div>
                        <div class="clearfix"></div>
                        <div class="weixin hidden-xs open">
                            <div id="qrcode_zoneb" style="text-align:center;margin:10px auto;width:200px;">

                            </div>
                            <p>请用手机微信扫一扫登录</p>
                        </div>
                        <div class="content">
                            <input type="text" placeholder="请输入手机号..." name="cellphone" style="background-color:#fff"/>
                            <input type="text" placeholder="请输入验证码号..." name="verify" id="verify"/>
                            <span class="code">
                                <button type="button" class="btn btn-warning btn-sm img-responsive" id="img">验证码</button>
                             
                            </span>
                           <a class="btn btn-warning" onclick="post()">登录</a>
                        </div>

                      
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-7 advert">
                    <!-- 多图滚动 -->
                
                    <div id="scrollBox" class="scrollBox" style="width:100%;height:100%;">
                        <div class="hd" >
                            <div style="float:left">
                                <span class="prev"></span>
                                <span class="next dir01"></span>
                            </div>
                            <ul></ul>

                        </div>
                        <div class="bd" id="banner" style="width:300px;height:300px;">
                            <ul v-for="item in items">
                                <li>
                                    <a class="pic" href="{{item.url}}"><img :src="item.thumb"/></a>                                  
                                </li>                               
                            </ul>
                         
                        </div>
                    </div>
                    <script src="//portalcdn.cloudshotspot.com/template/wx_mall/Scripts/TouchSlide.1.1.js"></script>
                    <script src="//portalcdn.cloudshotspot.com/cloud/js/vue/vue.min.js"></script>
                    <script type="text/javascript" src="//portalcdn.cloudshotspot.com/template/account_hotspot/js/pcauth.js" ></script>


                    <!-- scrollBox E -->
                    <script type="text/javascript">


        var $_GET = (function(){
        var url = window.document.location.href.toString();
        var u = url.split("?");
        if(typeof(u[1]) == "string"){
          u = u[1].split("&");
          var get = {};
          for(var i in u){
            var j = u[i].split("=");
            get[j[0]] = j[1];
          }
          return get;
        } else {
          return {};
        }

      })();


        var commonInit = [];
        var config = [];
        var skip_control;
    
        $(document).ready(function() {           
         
            $.ajax({
                url: '/portal/api/config',
                type: 'post',
                dataType: 'json',
                data: {'accesskey': $_GET['accesskey']},
              })
            .done(function(ret) {
                  //banner Json           
                  commonInit['banner'] = ret.banner;
                  //company Json
                  config['company'] = ret.copyright.company;
                  config['skip_time'] = ret.copyright.number;
                  config['title'] = ret.copyright.title;

                  //alert(config['skip_time']);
                  //check if allow ads func
                  if(ret.copyright.screen=='accept'){
                    //ok 
                    config['screen'] = true;                    
                    //ads screen pic
                    commonInit['screen']= ret.screen; 
                    //check if allow skip ads
                    if(ret.copyright.type=='accept'){
                      //ok
                      config['skip'] = true; 
                      //config['skip'] = false; 
                    }else{
                      config['skip'] = false;
                    }
                  }else{
                    
                    commonInit['screen']= [];
                    config['screen'] =false;
                  }
                  do_api();
               
                  
            });
          
        });
       

        function do_api(){


          var vm = new Vue({
            el: '#banner',
            data: {             
              items:commonInit['banner'],               
            }
          });

          var vm_init = new Vue({
            el: '#init',
            data: { 
              ok:config['screen'],            
              skip:config['skip'],            
              skip_time:config['skip_time'],            
              items:commonInit['screen'],
            }
          });
           TouchSlide({
              slideCell:"#scrollBox",
              titCell:".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
              effect:"leftLoop",
              autoPage:true, //自动分页
              switchLoad:"_src" //切换加载，真实图片路径为"_src"
            });



          var vm = new Vue({
            el: '#company',
            data: {             
              company:config['company'],               
            }
          });

          var vm = new Vue({
            el: '#con_title',
            data: {             
              title:config['title'],               
            }
          });

          if(config['screen']){
            skip_control=setInterval('skip_time()',1000); 

          }
        }

        function skip_time(){
         // alert(config['skip_time']);
          var time = parseInt(config['skip_time']);
          if(time==0){
            //clearIntervel(skip_control);
            clearInterval(skip_control);
            remove_skip();
            return;
          }
          //alert(time);
          //document.getElementById('skip_time').innerHtml='2';
          $("#skip_time").text(time);
          config['skip_time']--;

        }
      function remove_skip(){

        clearInterval(skip_control);
        $("#init").hide('fast/400');
      } 



      function onekey(){
        var url = "/portal/verify?accesskey="+$_GET['accesskey']+'&mac='+$_GET['mac']+'&ip='+$_GET['ip']+'&chaplogin='+$_GET['chaplogin'];
        window.location.href=url;
      }


        $(" .scrollBox .next").click(function () {
            if( $(this).hasClass("dir01")){
            
            }else{
                $(this).addClass("dir01")
                $(this).siblings("span").removeClass("dir")
            }
               
        })

        $(" .scrollBox .prev").click(function () {
            if ($(this).hasClass("dir")) {

            } else {
                $(this).addClass("dir")
                $(this).siblings("span").removeClass("dir01")
            }

        })

       



    var EndTime=60;
    var intvalue=0;
    var timer2=null;


     $("#img").click(function(event) {
            /* Act on the event */
        var cellphone = $("[name='cellphone']").val();
        if(cellphone=='' || cellphone==null){
            alert('请输入手机号码!');
            $("[name='cellphone']").focus();
            return false;
        }

        var re= /^1\d{10}$/;
        if(!re.test(cellphone)){
          alert('请输入正确的手机号码。');
          $("[name='cellphone']").focus();
          return false;
        }

        if(timer2==null){
           Message(cellphone);
        }
    });



    function Message(cellphone){
        //var form = $("#mikrotik").serialize();
       
        $.ajax({
            url:  "http://"+window.location.hostname+"/api/message/init",
            type: 'POST',
            dataType: 'json',
            data: {'accesskey':$_GET['accesskey'],'cellphone':cellphone,"mac":$_GET['mac']},
        })
        .done(function(info) {
           if(info.status=='ok'){
              timer2=window.setInterval("startShow()",1000);   
           }else{
              alert(info.message);
           }
        });      

    }

     $('#verify').keyup(function(){
          var verify = $(this).val();
          var cellphone = $("[name='cellphone']").val()
          if(verify.length<6 || verify.length>6) return false;
          $.ajax({
              url: "http://"+window.location.hostname+"/api/message/verify",
              type: 'POST',
              dataType: 'json',
              data:{'accesskey':$_GET['accesskey'],'cellphone':cellphone,'verify':verify},
          })
          .done(function(info) {
            
              if(info['status']=='success'){
                  endShow();
                  $("#mikrotik").attr('data-status','success');
                  $('#img').html('验证通过');                             
              }
          });
        
    });

    function post(){
      var check = $("#mikrotik").attr('data-status');
      if(check=="success"){
         //var url = "/portal/verify?accesskey="+$_GET['accesskey']+'&mac='+$_GET['mac']+'&ip='+$_GET['ip']+'&chaplogin='+$_GET['chaplogin'];
          var type = $_GET['chaplogin'];
          var url = "/portal/component/verify?mac="+$_GET['mac']+"&accesskey="+$_GET['accesskey']+"&chaplogin="+type;
          window.location.href=url; 
      }else{
        alert('请确认输入正确的验证码!');
        $("[name='password']").focus();
      }

    }



    function startShow(){
        intvalue ++;
        document.getElementById("img").innerHTML="&nbsp;" + ((EndTime-intvalue)%60).toString()+"秒后重发";
        if(intvalue>=EndTime){
            document.getElementById("img").innerHTML="重发!";
            endShow();
        }
    }

    function endShow(){
        window.clearTimeout(timer2);
        intvalue=0;
        timer2=null;
    }



        $(function () {



            $("#weixin").click(function () {
                if ($(".weixin").hasClass("open")) {
                    $(".weixin").removeClass("open");
                    $(".login .on").removeClass("on02");
                    $(".login .on01").removeClass("on02");
                } else {
                    $(".weixin").addClass("open");
                    $(".login .on").addClass("on02");
                    $(".login .on01").addClass("on02");

                    $.ajax({
                      url: '/portal/api/init',
                      type: 'POST',
                      dataType: 'json',
                      data: {"accesskey":$_GET['accesskey'],'mac':$_GET['mac']},
                    })
                    .done(function(ret) {

                     init(ret);
                    });
                }
                
            })


                  $.ajax({
                    url: '/portal/api/init',
                    type: 'POST',
                    dataType: 'json',
                    data: {"accesskey":$_GET['accesskey'],'mac':$_GET['mac']},
                  })
                  .done(function(ret) {

                   init(ret);
                  });
          

        })


function init(result){

    var type = $_GET['chaplogin'];
    JSAPI.auth({
      target : document.getElementById('qrcode_zoneb'),
      appId : result['appid'],
      shopId :result['shopid'],
      extend : "wechatpc",
      authUrl : "/portal/component/verify?mac="+$_GET['mac']+"&accesskey="+$_GET['accesskey']+"&chaplogin="+type,

    });
  }

                    </script>
                   
                </div>
            </div>
        </div>

    </div>
</body>
</html>
